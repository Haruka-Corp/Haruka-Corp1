

    <!-- container-scroller -->
    <!-- plugins:js -->
    <script  src="<?= base_url("assets/purple/assets/vendors/js/vendor.bundle.base.js")?>"></script>
    <!-- endinject -->
    <!-- Plugin js for this page -->
    <script  src="<?= base_url("assets/purple/assets/vendors/chart.js/Chart.min.js")?>"></script>
    <!-- End plugin js for this page -->
    <!-- inject:js -->
    <script  src="<?= base_url("assets/purple/assets/js/off-canvas.js")?>"></script>
    <script  src="<?= base_url("assets/purple/assets/js/hoverable-collapse.js")?>"></script>
    <script  src="<?= base_url("assets/purple/assets/js/misc.js")?>"></script>
    <!-- endinject -->
    <!-- Custom js for this page -->
    <!-- <script  src="<?= base_url("assets/purple/assets/js/dashboard.js")?>"></script> -->
    <script  src="<?= base_url("assets/purple/assets/js/todolist.js")?>"></script>
    <script  src="<?= base_url("assets/purple/assets/js/jquery.min.js")?>"></script>
    <script  src="<?= base_url("assets/purple/assets/js/jquery.qrcode.min.js")?>" type="text/javascript"></script>
    <script  src="<?= base_url("assets/purple/assets/js/script.js")?>" type="text/javascript"></script>
    <!-- End custom js for this page -->
  </body>
</html>